from distutils.core import setup

setup(
    name        =       'recur-dist',
    version     =       '1.0.0',
    py_modules  =       ['recur'],
    author      =       'jai',
    author_email=       'jainandhinis@gmail.com',
    url         =       'http://headfirstlabs.com',
    description =       'Sample recursion prog'
    )
